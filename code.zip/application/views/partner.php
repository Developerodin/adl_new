<link href="<?php echo base_url(); ?>/assets/css/mainpage.css" rel="stylesheet">


<div class="hero-section wf-section">
  <div class="container__solutions mb-5 text-center" style="min-height:800px;">
    
  <h1 class="h0 mt-30"> <span class="orange">Partners</span></h1>
    
  </div>
</div>